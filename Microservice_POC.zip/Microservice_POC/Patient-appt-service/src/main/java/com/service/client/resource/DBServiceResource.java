package com.service.client.resource;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.service.client.model.PatientAppointmentDetail;
import com.service.client.repository.PatientAppointmentRepository;

@RestController
@RequestMapping("/rest/db")
public class DBServiceResource {

	private PatientAppointmentRepository patientApptRepository;

	public DBServiceResource(PatientAppointmentRepository patientApptRepository) {
		this.patientApptRepository = patientApptRepository;
	}

	// -------------------Retrieve All
	// Users---------------------------------------------

	@RequestMapping(value = "/getAllPatientDetails", method = RequestMethod.GET)
	public List<PatientAppointmentDetail> getAllPatientDetails() {
		System.out
				.println("-----------------------inside getpatient---------------");
		return patientApptRepository.findAll();
	}

	// -------------------Create a New
	// Patient-------------------------------------------

	@RequestMapping(value = "/addNewPatient", method = RequestMethod.POST)
	public PatientAppointmentDetail createNewPatient(
			@RequestBody PatientAppointmentDetail patientappt) {
		return patientApptRepository.save(patientappt);
	}

	// -------------------Retrieve Single
	// User------------------------------------------
	@RequestMapping(value ="updatePatientDetails")
	public PatientAppointmentDetail update(@RequestParam Integer id,
			@RequestParam String patientName) {
		System.out.println(" ---------------- Id--------------- : " + id);
		PatientAppointmentDetail patientDet = patientApptRepository.findById(id).get();
		patientDet.setPatientName(patientName);
		patientDet = patientApptRepository.save(patientDet);
		return patientDet;
	}
	
	/**
	  * GET /delete  --> Delete a booking from the database.
	  */
	 @RequestMapping("/delete")
	 public String delete(@RequestParam Integer id) {
		 patientApptRepository.deleteById(id);
	     return "Patient Record with #"+id+" deleted successfully";
	 }

	/*
	 * @RequestMapping(value="/",method = RequestMethod.GET)
	 * 
	 * @HystrixCommand(fallbackMethod = "getDataFallBack") public String getid()
	 * { //PatientAppointmentDetail patientdetails = new
	 * PatientAppointmentDetail();
	 * System.out.println("-----------------------inside getpatient---------------"
	 * ); return "hello"; }
	 */

	/*
	 * public String getDataFallBack() {
	 * 
	 * PatientAppointmentDetail emp = new PatientAppointmentDetail();
	 * emp.setDoctorName("fallback-emp1"); emp.setHospital("fallback-manager");
	 * emp.setPatientName("fallback-1"); emp.setCheckUpType("None");
	 * 
	 * return "I am your fallback";
	 * 
	 * }
	 */
}
