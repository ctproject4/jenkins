package com.service.client.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "patientappointmentdetail")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class PatientAppointmentDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Integer id;

	@Column(name = "patient_name")
	private String patientName;
	
	@Column(name = "doctor_name")
	private String doctorName;
	
	@Column(name = "hospital")
	private String hospital;
	
	@Column(name = "checkUpType")
	private String checkUpType;
	
	public Integer getId() {
		return id;
	}
	
	public PatientAppointmentDetail(){
		
	}

	public PatientAppointmentDetail(String patientName,
			String doctorName, String hospital, String checkUpType) {
	
		this.patientName = patientName;
		this.doctorName = doctorName;
		this.hospital = hospital;
		this.checkUpType = checkUpType;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getHospital() {
		return hospital;
	}

	public void setHospital(String hospital) {
		this.hospital = hospital;
	}

	public String getCheckUpType() {
		return checkUpType;
	}

	public void setCheckUpType(String checkUpType) {
		this.checkUpType = checkUpType;
	}
	
}
