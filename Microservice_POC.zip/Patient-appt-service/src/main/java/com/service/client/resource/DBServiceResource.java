package com.service.client.resource;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.service.client.model.PatientAppointmentDetail;
import com.service.client.repository.PatientAppointmentRepository;

@RestController
@RequestMapping("/rest/db")
public class DBServiceResource {

private PatientAppointmentRepository patientApptRepository;
	
	public DBServiceResource(PatientAppointmentRepository patientApptRepository){
		this.patientApptRepository = patientApptRepository;
	}
	
	@RequestMapping(value="/a",method = RequestMethod.GET)
	public List<PatientAppointmentDetail> getQuotes() {
		System.out.println("-----------------------inside getpatient---------------");
	    return patientApptRepository.findAll();
	}
	
	@RequestMapping(value="/",method = RequestMethod.GET)
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	public String getid() {
		//PatientAppointmentDetail patientdetails = new PatientAppointmentDetail();
		System.out.println("-----------------------inside getpatient---------------" );
	    return "hello";
	}
	
	@RequestMapping(value="/add",method = RequestMethod.POST)
	public PatientAppointmentDetail createNewPatient(@RequestBody PatientAppointmentDetail patientappt) {
	    System.out.println("-------------" + patientappt.getDoctorName());
		return patientApptRepository.save(patientappt);
	}
	
	/*@RequestMapping("/")
	 public String welcome() {
	 return "Welcome to Spring Boot Tutorials";
	 }*/
	
	public String getDataFallBack() {
		/*
		PatientAppointmentDetail emp = new PatientAppointmentDetail();
		emp.setDoctorName("fallback-emp1");
		emp.setHospital("fallback-manager");
		emp.setPatientName("fallback-1");
		emp.setCheckUpType("None");*/

		return "I am your fallback";
		
	}
}
