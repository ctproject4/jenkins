package com.service.client.model;

import java.util.List;

public class PatientAppointments {

	private String patientName;
	private String doctorName;
	private String hospital;
	private List<String> checkUpType;
	
	public PatientAppointments(String patientName, String doctorName,
			String hospital, List<String> checkUpType) {
		super();
		this.patientName = patientName;
		this.doctorName = doctorName;
		this.hospital = hospital;
		this.checkUpType = checkUpType;
	}

	public PatientAppointments(){
		
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getHospital() {
		return hospital;
	}

	public void setHospital(String hospital) {
		this.hospital = hospital;
	}

	public List<String> getCheckUpType() {
		return checkUpType;
	}

	public void setCheckUpType(List<String> checkUpType) {
		this.checkUpType = checkUpType;
	}
	
}
