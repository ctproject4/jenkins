package com.service.client.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.service.client.model.PatientAppointmentDetail;

public interface PatientAppointmentRepository extends JpaRepository<PatientAppointmentDetail, Integer>{
	List<PatientAppointmentDetail> findByPatientName(String patientname);
}
