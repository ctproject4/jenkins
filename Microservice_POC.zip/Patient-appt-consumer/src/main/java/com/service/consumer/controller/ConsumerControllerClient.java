package com.service.consumer.controller;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.service.consumer.PatientApptConsumerApplication;

public class ConsumerControllerClient {
	
	private static final Logger logger = LoggerFactory.getLogger(ConsumerControllerClient.class);
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@Autowired
	private LoadBalancerClient loadBalancer;

	public void getPatientDetail() throws RestClientException, IOException {

		//String baseUrl = "http://localhost:8083/rest/db/a";
		
		List<ServiceInstance> instances=discoveryClient.getInstances("PATIENT-APPT-SERVICE");
		ServiceInstance serviceInstance=instances.get(0);
		
		//ServiceInstance serviceInstance_ribbon=loadBalancer.choose("Patient-appt-service");
		//String baseUrl=serviceInstance_ribbon.getUri().toString();
		String baseUrl=serviceInstance.getUri().toString();
		
		logger.debug("--------------------- soumya ---------------------------"+serviceInstance.getUri());
		
		baseUrl=baseUrl+"/rest/db/a";
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, getHeaders(),String.class);
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println(response.getBody());
	}
	
	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
}
